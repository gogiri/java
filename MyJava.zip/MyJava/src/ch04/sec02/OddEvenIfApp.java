package ch04.sec02;

public class OddEvenIfApp {

	public static void main(String[] args) {
		int num = (int)(Math.random()*6) + 1;
		
		if((num % 2) == 1) {
			System.out.println(num + ": 홀수");
		} else {
			System.out.println(num + ": 짝수");
		}

	}

}
