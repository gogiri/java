package ch04.sec02;

public class HakjumIfApp {

	public static void main(String[] args) {
		int kor = 88;
		int eng = 92;
		int math = 100;
		System.out.println("국어=" + kor + " 영어=" + eng + " 수학=" + math);
		System.out.println("합계=" + (kor + eng + math) + " 평균=" + ((kor + eng + math)/3) + " 학점=" + "A");
	}
}