package ch04.sec03;

public class HakjumSwitchApp {

    public static void main(String[] args) {

        // 시험 점수
        int kor = 88; // 국어
        int eng = 92; // 영어
        int math = 100; // 수학
        System.out.print("국어=" + kor);
        System.out.print(" 영어=" + eng);
        System.out.println(" 수학=" + math);

        // 시험 점수 합계, 평균
        int sum = kor + eng + math; // 합계
        int avg = sum / 3; // 평균
        System.out.print("합계=" + sum);
        System.out.print(" 평균=" + avg);

        // 학점
        char hakjum = 'F';
        int avgdata = avg / 10; // 몫

        switch (avgdata) {
        case 10:
            hakjum = 'A';
            break;
        case 9:
            hakjum = 'A';
            break;
        case 8:
            hakjum = 'B';
            break;
        case 7:
            hakjum = 'C';
            break;
        case 6:
            hakjum = 'D';
            break;
        default:
            hakjum = 'F';
        }
        System.out.println(" 학점=" + hakjum);

    }

}

