package ch04.sec03;

public class OddEvenSwitchApp {

	public static void main(String[] args) {
		int num = (int)(Math.random()*6) + 1;
		
		switch(num%2) {
			
			case 1:
				System.out.println(num + ": 홀수");
			break;
			
			default:
				System.out.println(num + ": 짝수");
		}

	}
}
