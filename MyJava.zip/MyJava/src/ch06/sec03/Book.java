package ch06.sec03;

public class Book {

}
