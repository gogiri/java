package ch06.sec03;

public class App {

	public static void main(String[] args) {
		System.out.println("App");
	}
	
}
