package ch01.sec08;

public class Hello {

	public static void main(String[] args) {
		System.out.println("sec08 입니다.");

	}

}
